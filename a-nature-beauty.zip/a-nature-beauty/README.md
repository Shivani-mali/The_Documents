# A NATURE BEAUTY.

A Pen created on CodePen.io. Original URL: [https://codepen.io/shiv-m/pen/BagQGzO](https://codepen.io/shiv-m/pen/BagQGzO).

