const logicButton = document.getElementById("logic-button");
const logicInput = document.getElementById("logic-input");
const proposal = document.getElementById("proposal");
const lines = document.querySelectorAll('.line');
const heartBackground = document.getElementById("heart-background");
const yesButton = document.getElementById("yes-button");
const finalPage = document.getElementById("final-page");
const playMusicButton = document.getElementById("play-music-button");

const keyword = "love"; // Set the unlocking keyword
const music = document.getElementById("background-music");

// Function to create heart rain effect
function createHeartRain() {
  for (let i = 0; i < 100; i++) {
    const heart = document.createElement('div');
    heart.classList.add('heart');
    heart.innerHTML = '❤️';
    heart.style.left = `${Math.random() * 100}vw`;
    heart.style.animationDuration = `${Math.random() * 5 + 5}s`;
    heartBackground.appendChild(heart);
  }
}

// Function to reveal lines one by one
function revealLines() {
  lines.forEach((line, index) => {
    setTimeout(() => {
      line.classList.add('show');
      line.style.animation = "bounce 0.5s";
    }, index * 2000);
  });
}

// Unlock Proposal Section
logicButton.addEventListener("click", () => {
  if (logicInput.value.toLowerCase() === keyword) {
    document.getElementById("avatar-section").style.display = "none";
    proposal.classList.remove("hidden");
    proposal.style.display = "block";

    // Play background music when the proposal section is revealed
    music.play();

    createHeartRain();
    revealLines();
  } else {
    alert("Oops! Try a different word.");
  }
});

// Final Page with button action
yesButton.addEventListener("click", () => {
  proposal.style.display = "none";
  finalPage.classList.remove("hidden");
  finalPage.style.display = "block";
  heartBackground.innerHTML = ""; // Stop heart rain
});

// Play button for background music
playMusicButton.addEventListener("click", () => {
  music.play();
});
